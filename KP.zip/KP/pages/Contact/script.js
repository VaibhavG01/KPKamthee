
document.getElementById('navToggle').addEventListener('click', function() {
    document.getElementById('navSidebar').classList.toggle('active');
});
